import { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Server-first: RSC fetch through the generated client; client components
  // only where interactivity is real (camera, audio, confirm chips).
  reactStrictMode: true,
  output: "standalone",
};

export default nextConfig;
