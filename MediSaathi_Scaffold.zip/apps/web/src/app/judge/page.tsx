"use client";

/**
 * Judge route stub - sealed cases, 90-second script timer, cached-mode toggle.
 * Block B8 completes: auto-advance timeline, provenance drawer, contrast mode.
 */
export default function JudgePage() {
  return (
    <main className="mx-auto max-w-2xl px-8 py-20">
      <p className="text-xs uppercase tracking-[0.25em]" style={{ color: "var(--accent)" }}>
        Judge route - sealed cases
      </p>
      <h1 className="mt-3 text-3xl font-bold" style={{ color: "var(--primary)" }}>
        The 90-second walkthrough
      </h1>
      <ol className="mt-8 list-decimal space-y-3 pl-6 text-sm">
        <li>Clean prescription - extraction, verdict, spoken plan (Tamil)</li>
        <li>Severe interaction - warfarin + aspirin, source cited</li>
        <li>Contraindication - doxycycline for a child</li>
        <li>Corrupted scan - the refusal moment</li>
      </ol>
      <p className="mt-8 text-xs" style={{ color: "var(--muted)" }}>
        Cached mode ships with Block B8. API route already answers /api/v1/judge/cases.
      </p>
    </main>
  );
}
