"use client";

/**
 * Capture flow stub - Block B5 fills this in (camera, sample picker, states).
 * The offline demo path picks a sealed sample; the live path opens the camera.
 */
const SAMPLES = [
  { id: "RX-001", label: "Clean printed Rx (2 medicines)" },
  { id: "RX-002", label: "Warfarin + aspirin (severe interaction)" },
  { id: "RX-004", label: "Duplicate paracetamol brands" },
  { id: "RX-009", label: "Doxycycline for a child (contraindication)" },
  { id: "RX-003", label: "Handwritten - low confidence (confirm queue)" },
  { id: "RX-006", label: "Corrupted scan (refusal)" },
];

export default function ScanPage() {
  async function scan(sampleId: string) {
    const { api } = await import("@/lib/api");
    const env = await api.start(sampleId);
    const verdict = (env.meta as { verdict?: string }).verdict;
    alert(`Sample ${sampleId}: verdict = ${verdict}. Plan UI lands at Block B5.`);
  }

  return (
    <main className="mx-auto max-w-2xl px-8 py-20">
      <h1 className="text-3xl font-bold" style={{ color: "var(--primary)" }}>
        Scan a prescription
      </h1>
      <p className="mt-3 text-sm" style={{ color: "var(--muted)" }}>
        Demo path: pick a sealed sample (works fully offline). Camera capture lands at Block B5.
      </p>
      <ul className="mt-8 grid gap-3">
        {SAMPLES.map((s) => (
          <li key={s.id}>
            <button
              onClick={() => scan(s.id)}
              className="w-full rounded-xl border bg-white px-5 py-4 text-left hover:border-[var(--accent)]"
            >
              <span className="font-mono text-xs" style={{ color: "var(--accent)" }}>
                {s.id}
              </span>
              <span className="ml-3">{s.label}</span>
            </button>
          </li>
        ))}
      </ul>
    </main>
  );
}
