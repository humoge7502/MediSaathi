export default function Home() {
  return (
    <main className="mx-auto max-w-3xl px-8 py-24">
      <p className="text-sm uppercase tracking-[0.2em]" style={{ color: "var(--accent)" }}>
        MediSaathi
      </p>
      <h1 className="mt-4 text-5xl font-bold leading-tight" style={{ color: "var(--primary)" }}>
        Every prescription, understood.
      </h1>
      <p className="mt-6 text-lg" style={{ color: "var(--muted)" }}>
        Snap the prescription. Get back a verified, spoken medicine plan - screened for
        interactions, priced against generics, and refused instead of guessed when
        confidence drops.
      </p>
      <a href="/scan" className="mt-10 inline-block rounded-lg px-6 py-3 text-white" style={{ background: "var(--primary)" }}>
        Scan a prescription
      </a>
      <p className="mt-16 text-xs" style={{ color: "var(--muted)" }}>
        MediSaathi is an information tool, not a doctor. Discuss every medicine with your
        pharmacist or doctor.
      </p>
    </main>
  );
}
