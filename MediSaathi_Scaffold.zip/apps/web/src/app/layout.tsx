import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "MediSaathi - Every prescription, understood",
  description:
    "Verification-first prescription intelligence: photo to verified, spoken medication plan in Tamil, Hindi, or English.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
