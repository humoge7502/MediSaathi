/**
 * Typed API client - envelope contract mirrors packages/contracts.
 * Regenerate against the live OpenAPI schema at Block B4 contract freeze.
 */
export const API_BASE = process.env.NEXT_PUBLIC_API_BASE ?? "http://localhost:8000";

export interface Envelope<T = Record<string, unknown>> {
  ok: boolean;
  data: T | null;
  error: string | null;
  meta: Record<string, unknown>;
}

export interface ConfirmItem {
  field_index: number;
  raw_text: string;
  confidence: number;
  reason: string;
}

export interface PrescriptionState {
  prescription_id: string;
  sample_id: string;
  extraction: { fields: { raw_text: string; brand_text: string; confidence: number }[] } | null;
  verdict: { kind: string; headline: string; detail: string } | null;
  confirm_queue: ConfirmItem[];
}

async function get<T>(path: string): Promise<Envelope<T>> {
  const res = await fetch(`${API_BASE}${path}`, { cache: "no-store" });
  if (!res.ok && res.status !== 409) throw new Error(`API ${res.status}`);
  return res.json();
}

export const api = {
  start: (sampleId: string, context = "") =>
    get<PrescriptionState>(`/api/v1/prescriptions?sample_id=${sampleId}&context=${context}`),
  state: (id: string) => get<PrescriptionState>(`/api/v1/prescriptions/${id}`),
  plan: (id: string, lang: "en" | "ta" | "hi" = "en") =>
    get<{ script: string; slots: { slot: string; value: string; verified: boolean }[] }>(
      `/api/v1/prescriptions/${id}/explanation?lang=${lang}`),
  price: (id: string) =>
    get<{ rows: { brand: string; molecule: string; unit_price_inr: number | null; generic_price_inr: number | null }[] }>(
      `/api/v1/prescriptions/${id}/price`),
  judgeCases: () => get<{ sealed: { sample_id: string; description: string }[] }>("/api/v1/judge/cases"),
};
