"""Verdict assembly: the gate law lives here.

Decision order (first match wins):
  1. image unusable (RefusalCandidate)            -> refused
  2. any field below REFUSE_BELOW (0.75)          -> refused
  3. no formulary match at all                    -> confirm_queue
  4. any low-confidence / unmatched fields        -> confirm_queue
  5. any contraindication or severe interaction   -> interaction / contraindication
  6. duplicate ATC                                -> duplicate_atc
  7. moderate interaction                         -> interaction
  8. otherwise                                    -> pass

The verdict NEVER exposes unverified fields to the spoken plan; if the queue
is non-empty, `all_verified` is False and the plan endpoint returns 409 until
a human resolves the queue.
"""
from __future__ import annotations

from medisaathi_contracts import (
    ConfirmItem,
    ProvenanceEntry,
    Severity,
    Verdict,
    VerdictKind,
)
from medisaathi_contracts.models import ExtractionResult, SafetyReport

from .safety.engine import REFUSE_BELOW, SafetyEngine


def assemble(engine: SafetyEngine, extraction: ExtractionResult,
             report: SafetyReport, confirm_items: list[ConfirmItem]) -> Verdict:
    prov = engine.provenance()
    prov.append(ProvenanceEntry(
        kind="extraction", name="field extraction",
        source=f"{extraction.engine}; per-field confidence recorded",
        snapshot="live"))

    if extraction.fields and all(f.confidence < REFUSE_BELOW for f in extraction.fields):
        return Verdict(
            kind=VerdictKind.refused,
            headline="Refused: image could not be verified",
            detail=("No prescription content was detected. MediSaathi does not guess "
                    "from unusable images. Retake the photo in even light, flat and "
                    "in focus."),
            refusal_reason="all_fields_below_refusal_threshold",
            provenance=prov)

    if any(f.confidence < REFUSE_BELOW for f in extraction.fields):
        return _queue(confirm_items, prov, "fields below refusal threshold")

    if not report.medications:
        return _queue(confirm_items, prov, "no medicine matched the formulary map")

    if confirm_items:
        return _queue(confirm_items, prov, "low-confidence fields await confirmation")

    if report.contraindications:
        c = report.contraindications[0]
        return Verdict(
            kind=VerdictKind.contraindication,
            headline=f"Contraindication flagged: {c.molecule}",
            detail=f"{c.condition_code}: {c.note}",
            max_interaction_severity=Severity.severe,
            provenance=prov)

    sev = Severity.none
    if report.interactions:
        sev = max((i.severity for i in report.interactions),
                  key=lambda s: {"none": 0, "mild": 1, "moderate": 2, "severe": 3}[s.value])
        if sev == Severity.severe:
            worst = next(i for i in report.interactions if i.severity == sev)
            return Verdict(
                kind=VerdictKind.interaction,
                headline=f"Severe interaction: {worst.molecule_a} + {worst.molecule_b}",
                detail=worst.mechanism,
                max_interaction_severity=sev,
                provenance=prov)

    if report.duplicates:
        d = report.duplicates[0]
        return Verdict(
            kind=VerdictKind.duplicate_atc,
            headline=f"Duplicate medicines: {' + '.join(d.brands)}",
            detail=d.note,
            provenance=prov)

    if sev == Severity.moderate:
        worst = next(i for i in report.interactions if i.severity == sev)
        return Verdict(
            kind=VerdictKind.interaction,
            headline=f"Moderate interaction: {worst.molecule_a} + {worst.molecule_b}",
            detail=worst.mechanism,
            max_interaction_severity=sev,
            provenance=prov)

    return Verdict(
        kind=VerdictKind.pass_,
        headline="All checks passed",
        detail="Every medicine was matched, normalized, and screened. "
               "No interactions, contraindications, or duplicates found.",
        provenance=prov)


def _queue(items: list[ConfirmItem], prov: list[ProvenanceEntry],
           reason: str) -> Verdict:
    return Verdict(
        kind=VerdictKind.confirm_queue,
        headline="Confirmation needed",
        detail=f"{reason}. {len(items)} field(s) need a human yes/no before the "
               "safety verdict is issued. This queue is the product working, "
               "not failing.",
        refusal_reason=None,
        provenance=prov)
