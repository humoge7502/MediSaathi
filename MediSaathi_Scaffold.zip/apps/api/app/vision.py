"""Perception plane: fixture-first, live-optional vision extraction.

LAW OF THE PIPELINE: this module returns per-field confidence and nothing
else enters the safety plane. If MEDISAATHI_VISION_KEY is set, a real
vision-LLM call is attempted; otherwise the sealed fixture corpus answers,
which is also the offline demo path (three-tier fallback, tier 2-3).
"""
from __future__ import annotations

import json
import os
import time

from medisaathi_contracts import ExtractionField, ExtractionResult, FieldSource

FIXTURE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "fixtures")
LIVE_KEY = os.environ.get("MEDISAATHI_VISION_KEY", "")
LIVE_MODEL = os.environ.get("MEDISAATHI_VISION_MODEL", "gemini-2.0-flash")


class RefusalCandidate(Exception):
    """Raised when the image cannot possibly contain a prescription."""


def load_fixture(sample_id: str) -> dict:
    path = os.path.join(FIXTURE_DIR, f"{sample_id}.json")
    if not os.path.exists(path):
        raise FileNotFoundError(f"unknown fixture {sample_id}")
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _parse_line(text: str, conf: float, source: FieldSource) -> ExtractionField:
    """Regex-light line parser for seed fixtures (real parsing lives in the
    live vision path's JSON schema; fixtures ship pre-segmented lines)."""
    import re
    cleaned = text.strip()
    # strip list numbering
    cleaned = re.sub(r"^\\d+\\.\\s*", "", cleaned)
    brand_text = cleaned.split(" - ")[0]
    dose = ""
    freq = ""
    duration = ""
    m = re.search(r"(\\d+-\\d+-\\d+)", cleaned)
    if m:
        freq = m.group(1)
    m = re.search(r"x\\s*(\\d+\\s*days?)", cleaned, re.I)
    if m:
        duration = m.group(1)
    m = re.search(r"(\\d+\\s*mg|\\d+\\s*g|\\d+\\s*ml|\\d+\\s*mcg)", cleaned, re.I)
    if m:
        dose = m.group(1)
    return ExtractionField(
        raw_text=text, brand_text=brand_text, dose=dose, frequency=freq,
        duration=duration, confidence=conf, source=source,
    )


def extract(sample_id: str) -> ExtractionResult:
    """Extract fields for a sample. Fixture path is deterministic and offline."""
    t0 = time.perf_counter()
    page = load_fixture(sample_id)
    if page.get("blank") or page.get("non_rx"):
        raise RefusalCandidate(
            "no prescription content detected in the image "
            "(blank scan or non-prescription document)")
    fields = [
        _parse_line(line["text"], float(line["conf"]), FieldSource.seed_fixture)
        for line in page.get("lines", [])
    ]
    latency = int((time.perf_counter() - t0) * 1000)
    return ExtractionResult(sample_id=sample_id, fields=fields,
                            engine="fixture-v0", latency_ms=latency)


def extract_live(image_bytes: bytes) -> ExtractionResult:
    """Live vision-LLM path. Kept behind an env key; NOT used in the offline
    demo. JSON-schema constrained, temperature 0, one retry on schema failure.
    Below-threshold fields NEVER bypass the confirm queue."""
    if not LIVE_KEY:
        raise RuntimeError("live vision requires MEDISAATHI_VISION_KEY")
    # Real client call lands here during Block B2 (see master plan, section 34).
    raise NotImplementedError("live extraction is implemented at hour B2; fixtures carry the demo")
