"""Template-grounded NLG.

LAW: the voice may only rephrase within verified slots. Every drug name,
dose, and frequency in spoken output is copied from fields that passed the
confidence gate - the template never authors clinical content.
"""
from __future__ import annotations

from medisaathi_contracts import (
    NormalizedMedication,
    PlanSlot,
    SafetyReport,
    Severity,
    SpokenPlan,
)

_TEMPLATES = {
    "en": {
        "open": "Your medicine plan has {n} medicine{s}.",
        "med": "Medicine {i}: {brand}, contains {molecule}. Take {freq} for {dur}.",
        "med_nodur": "Medicine {i}: {brand}, contains {molecule}. Take {freq}.",
        "warn": "Important: {sev} interaction between {a} and {b}. {mechanism} Please discuss with your pharmacist or doctor.",
        "contra": "Important: {molecule} is not advised in this situation. {note}",
        "dup": "Note: {brands} belong to the same medicine class. Taking both together doubles the dose.",
        "close": "This is information, not medical advice. Talk to your pharmacist or doctor before changes.",
    },
    "ta": {
        "open": "உங்கள் மருந்து திட்டத்தில் {n} மருந்து{s} உள்ளது.",
        "med": "மருந்து {i}: {brand}, {molecule} கொண்டது. {freq} {dur} எடுங்கள்.",
        "med_nodur": "மருந்து {i}: {brand}, {molecule} கொண்டது. {freq} எடுங்கள்.",
        "warn": "முக்கியம்: {a} மற்றும் {b} இடையே {sev} தொடர்பு உள்ளது. மருந்தாளரை அணுகவும்.",
        "contra": "முக்கியம்: இந்த நிலையில் {molecule} பரிந்துரைக்கப்படவில்லை.",
        "dup": "குறிப்பு: {brands} ஒரே வகுப்பைச் சேர்ந்தவை. இரண்டையும் எடுத்தால் அளவு இரட்டிப்பாகும்.",
        "close": "இது தகவல் மட்டுமே, மருத்துவ ஆலோசனை அல்ல.",
    },
    "hi": {
        "open": "आपकी दवा योजना में {n} दवा{s} है।",
        "med": "दवा {i}: {brand}, इसमें {molecule} है। {freq} {dur} लें।",
        "med_nodur": "दवा {i}: {brand}, इसमें {molecule} है। {freq} लें।",
        "warn": "महत्वपूर्ण: {a} और {b} में {sev} अंतर्क्रिया है। फार्मासिस्ट से सलाह लें।",
        "contra": "महत्वपूर्ण: इस स्थिति में {molecule} की सलाह नहीं दी जाती।",
        "dup": "ध्यान दें: {brands} एक ही वर्ग की हैं। दोनों लेने से खुराक दोगुनी हो जाएगी।",
        "close": "यह केवल जानकारी है, चिकित्सा सलाह नहीं।",
    },
}

_SEV_WORD = {
    "en": {"mild": "a mild", "moderate": "a moderate", "severe": "a severe"},
    "ta": {"mild": "லேசான", "moderate": "நடுத்தர", "severe": "கடுமையான"},
    "hi": {"mild": "हल्की", "moderate": "मध्यम", "severe": "गंभीर"},
}


def build_spoken_plan(language: str, meds: list[NormalizedMedication],
                      report: SafetyReport) -> SpokenPlan:
    t = _TEMPLATES.get(language, _TEMPLATES["en"])
    slots: list[PlanSlot] = []

    def slot(name: str, value: str) -> str:
        slots.append(PlanSlot(slot=name, value=value, verified=True))
        return value

    parts: list[str] = []
    n = slot("count", str(len(meds)))
    parts.append(t["open"].format(n=n, s="" if len(meds) == 1 else "s"))

    for i, m in enumerate(meds, start=1):
        b = slot(f"med{i}.brand", m.brand)
        mol = slot(f"med{i}.molecule", m.molecule)
        # frequency and duration come from the first field, verified at gate
        freq = slot(f"med{i}.frequency", (m.fields[0].frequency if m.fields else ""))
        dur = (m.fields[0].duration if m.fields else "")
        if dur:
            parts.append(t["med"].format(i=i, brand=b, molecule=mol,
                                         freq=freq, dur=slot(f"med{i}.duration", dur)))
        else:
            parts.append(t["med_nodur"].format(i=i, brand=b, molecule=mol, freq=freq))

    for it in report.interactions:
        if it.severity in (Severity.moderate, Severity.severe):
            parts.append(t["warn"].format(
                sev=_SEV_WORD[language if language in _SEV_WORD else "en"][it.severity.value],
                a=slot("warn.a", it.molecule_a), b=slot("warn.b", it.molecule_b),
                mechanism="" if language != "en" else it.mechanism))

    for c in report.contraindications:
        parts.append(t["contra"].format(molecule=slot("contra.molecule", c.molecule)))

    for d in report.duplicates:
        parts.append(t["dup"].format(brands=slot("dup.brands", " + ".join(d.brands))))

    parts.append(t["close"])
    return SpokenPlan(language=language, slots=slots, script=" ".join(parts))
