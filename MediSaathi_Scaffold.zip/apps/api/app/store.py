"""In-memory prescription store (SQLite swap-in lands at B4 integration)."""
from __future__ import annotations

import uuid

from medisaathi_contracts import PrescriptionState

# prescription_id -> PrescriptionState
_STORE: dict[str, PrescriptionState] = {}


def create(sample_id: str) -> PrescriptionState:
    rx = PrescriptionState(prescription_id=str(uuid.uuid4()), sample_id=sample_id)
    _STORE[rx.prescription_id] = rx
    return rx


def get(prescription_id: str) -> PrescriptionState | None:
    return _STORE.get(prescription_id)


def put(rx: PrescriptionState) -> None:
    _STORE[rx.prescription_id] = rx
