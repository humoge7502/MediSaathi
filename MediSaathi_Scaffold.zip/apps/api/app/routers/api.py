"""API v1 routes: pipeline, plan, price, ADR draft."""
from __future__ import annotations

import csv
import os
from typing import Optional

from fastapi import APIRouter, HTTPException
from medisaathi_contracts import (
    Envelope,
    ExtractionResult,
    FieldSource,
    PlanSlot,
    PrescriptionState,
    PriceRow,
    SafetyReport,
    SpokenPlan,
    VerdictKind,
)
from pydantic import BaseModel, Field

from ..nlg import build_spoken_plan
from ..safety.engine import SafetyEngine
from ..store import create, get, put
from ..verdict import assemble
from ..vision import RefusalCandidate, extract

DATA_DIR = os.environ.get(
    "MEDISAATHI_DATA_DIR",
    os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..", "..", "..", "data")))

router = APIRouter(prefix="/api/v1")
engine = SafetyEngine.load(DATA_DIR)


# ------------------------------------------------------------------ models
class ConfirmRequest(BaseModel):
    field_index: int
    brand_text: str = Field(min_length=1)
    accepted: bool = True


class AdrDraft(BaseModel):
    prescription_id: Optional[str] = None
    medicine: str
    reaction: str
    severity: str = "moderate"
    onset_days: int = 1
    outcome: str = "recovering"


# ------------------------------------------------------------------ pipeline
@router.post("/prescriptions")
def start_prescription(sample_id: str, context: str = "") -> Envelope:
    """Start the pipeline for a sample (fixture) prescription.

    `context` is a comma-separated patient-context key list, e.g.
    "pregnancy,peptic_ulcer" - consumed ONLY by the deterministic rule engine.
    """
    rx = create(sample_id)
    ctx = {k.strip(): True for k in context.split(",") if k.strip()}
    try:
        result: ExtractionResult = extract(sample_id)
    except RefusalCandidate as e:
        rx.verdict = _refusal(engine, str(e))
        put(rx)
        return Envelope(data=rx.model_dump(), meta={"verdict": "refused"})
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail=f"unknown sample {sample_id}")

    report, items, _all_verified = engine.run(result.fields, ctx)
    confirms = [
        {"field_index": i["field_index"], "raw_text": i["raw_text"],
         "confidence": i["confidence"], "reason": i["reason"]}
        for i in items
    ]
    rx.extraction = result
    rx.safety = report
    rx.confirm_queue = confirms
    rx.verdict = assemble(engine, result, report, rx.confirm_queue)
    put(rx)
    return Envelope(data=rx.model_dump(), meta={
        "verdict": rx.verdict.kind.value,
        "latency_ms": result.latency_ms,
        "checks": report.checks,
    })


def _refusal(engine_ref: SafetyEngine, reason: str):
    """Refusal verdict for unusable images (refusal-as-feature)."""
    from medisaathi_contracts import Verdict
    return Verdict(
        kind=VerdictKind.refused,
        headline="Refused: image could not be verified",
        detail=reason + " MediSaathi refuses rather than guesses.",
        refusal_reason="no_prescription_content",
        provenance=engine_ref.provenance())


@router.get("/prescriptions/{prescription_id}")
def prescription_state(prescription_id: str) -> Envelope:
    rx = get(prescription_id)
    if rx is None:
        raise HTTPException(status_code=404, detail="unknown prescription")
    return Envelope(data=rx.model_dump(), meta={"verdict": (rx.verdict.kind.value if rx.verdict else "pending")})


@router.post("/prescriptions/{prescription_id}/confirm")
def confirm_field(prescription_id: str, body: ConfirmRequest) -> Envelope:
    rx = get(prescription_id)
    if rx is None:
        raise HTTPException(status_code=404, detail="unknown prescription")
    if rx.extraction is None or not (0 <= body.field_index < len(rx.extraction.fields)):
        raise HTTPException(status_code=422, detail="field_index out of range")
    if not body.accepted:
        raise HTTPException(status_code=422, detail="rejected fields go back to retake")

    fld = rx.extraction.fields[body.field_index]
    row = engine.normalize(body.brand_text)
    if row is None:
        raise HTTPException(status_code=422, detail="brand not in formulary map")
    fld.brand_text = row["brand"]
    fld.confidence = 1.0
    fld.source = FieldSource.user_confirmation
    rx.confirm_queue = [c for c in rx.confirm_queue if c["field_index"] != body.field_index]

    ctx = {}
    report, items, _ = engine.run(rx.extraction.fields, ctx)
    rx.safety = report
    rx.confirm_queue = [
        {"field_index": i["field_index"], "raw_text": i["raw_text"],
         "confidence": i["confidence"], "reason": i["reason"]} for i in items]
    rx.verdict = assemble(engine, rx.extraction, report, rx.confirm_queue)
    put(rx)
    return Envelope(data=rx.model_dump(), meta={"verdict": rx.verdict.kind.value})


# ------------------------------------------------------------------ plan
@router.get("/prescriptions/{prescription_id}/explanation")
def explanation(prescription_id: str, lang: str = "en") -> Envelope:
    rx = get(prescription_id)
    if rx is None:
        raise HTTPException(status_code=404, detail="unknown prescription")
    if rx.verdict and rx.verdict.kind in (VerdictKind.refused, VerdictKind.confirm_queue):
        raise HTTPException(status_code=409, detail="plan blocked until verdict is verified")
    if rx.safety is None or rx.extraction is None:
        raise HTTPException(status_code=409, detail="pipeline not finished")
    lang = lang if lang in ("en", "ta", "hi") else "en"
    plan: SpokenPlan = build_spoken_plan(lang, rx.safety.medications, rx.safety)
    plan.audio_url = None  # pre-baked phrase audio attaches at Block B6
    rx.spoken_plan = plan
    put(rx)
    return Envelope(data=plan.model_dump(), meta={"slots_verified": all(s.verified for s in plan.slots)})


# ------------------------------------------------------------------ price
@router.get("/prescriptions/{prescription_id}/price")
def price(prescription_id: str) -> Envelope:
    rx = get(prescription_id)
    if rx is None:
        raise HTTPException(status_code=404, detail="unknown prescription")
    if rx.safety is None:
        raise HTTPException(status_code=409, detail="pipeline not finished")
    # molecule-level lowest generic price across the formulary (Jan Aushadhi)
    best: dict[str, float] = {}
    for row in rx.safety.medications:
        for mol in row.molecule.split("+"):
            mol = mol.strip().lower()
            for b in engine.brands.values():
                mols = [m.strip().lower() for m in b["molecule"].split("+")]
                if mol in mols and b.get("jas_price_inr"):
                    best[mol] = min(best.get(mol, 1e9), b["jas_price_inr"])
    rows = []
    for m in rx.safety.medications:
        mol = m.molecule.split("+")[0].strip().lower()
        gen = best.get(mol)
        rows.append(PriceRow(
            brand=m.brand, molecule=m.molecule, unit_price_inr=m.jas_price_inr,
            generic_available=gen is not None,
            generic_price_inr=gen,
            source="Jan Aushadhi; snapshot 2026-09").model_dump())
    return Envelope(data={"rows": rows}, meta={"snapshot": "2026-09"})


# ------------------------------------------------------------------ ADR
@router.post("/adr-reports")
def adr_draft(body: AdrDraft) -> Envelope:
    """One-tap structured PvPI-format adverse-event draft (information layer)."""
    draft = {
        "report_type": "suspected adverse drug reaction",
        "patient_age_group": "not-collected (privacy)",
        "suspected_medicine": body.medicine,
        "reaction": body.reaction,
        "seriousness": body.severity,
        "onset_days_after_start": body.onset_days,
        "outcome": body.outcome,
        "channel": "PvPI (PvMICC) paper/online form draft - review before submission",
        "disclaimer": "Draft for your pharmacist or doctor to review and submit.",
    }
    return Envelope(data=draft, meta={"format": "pvpi-draft-v0"})
