"""Judge route: sealed demo cases + zero-network cached responses."""
from __future__ import annotations

import json
import os

from fastapi import APIRouter, HTTPException

from ..store import get, put
from .api import engine, router as api_router  # reuse pipeline internals

JUDGE_FLAG = os.environ.get("MEDISAATHI_JUDGE_OPEN", "1") == "1"
CACHE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data", "judge_cache.json")
SEAL_ORDER = ["RX-001", "RX-002", "RX-009", "RX-006"]  # clean, severe, contra, refusal

judge = APIRouter(prefix="/api/v1/judge")


@judge.get("/cases")
def cases() -> dict:
    if not JUDGE_FLAG:
        raise HTTPException(status_code=403, detail="judge route closed")
    manifest_path = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), "..", "..", "..", "..", "data",
        "cases_manifest.json")
    with open(manifest_path, encoding="utf-8") as f:
        manifest = {m["sample_id"]: m for m in json.load(f)}
    return {
        "sealed": [
            {"sample_id": sid, "description": manifest[sid]["description"],
             "expect_verdict": manifest[sid]["expected_verdict"]}
            for sid in SEAL_ORDER if sid in manifest
        ],
        "script_seconds": 90,
        "cached_mode_recommended": True,
    }


@judge.get("/cases/{sample_id}/cached")
def cached_case(sample_id: str) -> dict:
    """Pre-baked full response - the zero-network demo tier."""
    if not JUDGE_FLAG:
        raise HTTPException(status_code=403, detail="judge route closed")
    if os.path.exists(CACHE_PATH):
        with open(CACHE_PATH, encoding="utf-8") as f:
            cache = json.load(f)
        if sample_id in cache:
            return cache[sample_id]
    raise HTTPException(status_code=404, detail=f"no cached response for {sample_id}")
