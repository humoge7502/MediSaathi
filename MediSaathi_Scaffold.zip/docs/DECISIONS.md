# Decision Log (append-only)

| When | Decision | Why |
|---|---|---|
| T+0 | Two-plane architecture; LLM never touches safety decisions | Refusal-first product thesis; survives free-tier quota loss |
| T+0 | Fixtures carry the demo; live vision behind env key | Zero-failure demo; three-tier fallback |
| T+0 | Contracts package first; API generated from it | Frontend cannot drift from backend |
| T+0 | Confirm band 0.75-0.90, refuse below 0.75 | Product law; tuned per-field post-event |
| T+0 | Template-grounded NLG (no free generation of doses) | Spoken output traceable to verified slots, tested |
| T+0 | SQLite in-memory for event build; Postgres post-event | Boring on purpose; migration scripted later |
| T+0 | Refusal = HTTP 200 with refused verdict | Refusal is a designed success state, not an error |
