"""MediSaathi eval CLI.

Runs the fixture corpus through the pipeline and reports field accuracy and
verdict agreement against data/eval_labels.csv. The A1-vs-A4 ablation harness
expands here during Block B7 (master plan, section 34).

Usage (from repo root, after setup):
    python eval/eval.py            # table + score
    python eval/eval.py --json     # machine-readable results (committed per build)
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "apps", "api")))
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "packages", "contracts")))

from app.routers.api import engine  # noqa: E402
from app.verdict import assemble  # noqa: E402
from app.vision import RefusalCandidate, extract  # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
LABELS = os.path.join(ROOT, "data", "eval_labels.csv")
MANIFEST = os.path.join(ROOT, "data", "cases_manifest.json")


def load_labels() -> dict:
    labels = {}
    if os.path.exists(LABELS):
        with open(LABELS, encoding="utf-8") as f:
            for row in csv.DictReader(f):
                labels[row["sample_id"]] = row
    return labels


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true", dest="as_json")
    args = ap.parse_args()

    with open(MANIFEST, encoding="utf-8") as f:
        manifest = json.load(f)
    labels = load_labels()

    rows, field_hits, field_total = [], 0, 0
    for case in manifest:
        sid = case["sample_id"]
        try:
            result = extract(sid)
            ctx = {k: True for k in case.get("context", [])}
            report, items, _ = engine.run(result.fields, ctx)
            verdict = assemble(engine, result, report, items)
            got_brands = sorted(m.brand for m in report.medications)
            got_verdict = verdict.kind.value
            refused = verdict.kind.value == "refused"
        except RefusalCandidate:
            got_brands, got_verdict, refused = [], "refused", True
        expected_brands = sorted(case["expected_brands"])
        expected_verdict = case["expected_verdict"]
        # manifest labels carry severity suffixes; the enum's kind is the base
        base = expected_verdict.replace("_severe", "").replace("_moderate", "")
        if expected_brands:
            hits, total = len(set(got_brands) & set(expected_brands)), len(expected_brands)
        else:
            # refused cases: nothing expected, nothing extracted = full credit
            hits, total = (1, 1) if not got_brands else (0, 1)
        field_hits += hits
        field_total += total
        rows.append({
            "sample_id": sid,
            "brands_extracted": ";".join(got_brands),
            "brands_expected": ";".join(expected_brands),
            "brand_recall": round(hits / total, 3),
            "verdict": got_verdict,
            "verdict_expected": expected_verdict,
            "verdict_agree": str(got_verdict == base),
            "refusal_precise": str((base == "refused") == refused),
        })

    brand_recall = round(field_hits / max(field_total, 1), 4)
    verdict_agree = round(
        sum(1 for r in rows if r["verdict_agree"] == "True") / len(rows), 4)
    refusal_precision = round(
        sum(1 for r in rows if r["refusal_precise"] == "True") / len(rows), 4)

    result_block = {
        "benchmark": "medisaathi-fixture-v0",
        "n": len(rows),
        "brand_recall": brand_recall,
        "verdict_agreement": verdict_agree,
        "refusal_precision": refusal_precision,
        "ablation": "A1-vs-A4 harness lands at Block B7; this table is the A4 column",
        "build_tag": os.environ.get("MEDISAATHI_BUILD_TAG", "dev"),
    }

    if args.as_json:
        print(json.dumps({"results": result_block, "cases": rows}, indent=2))
    else:
        print(f"n={len(rows)}  brand_recall={brand_recall}  "
              f"verdict_agreement={verdict_agree}  refusal_precision={refusal_precision}")
        print(f"{'case':8} {'brands':28} {'verdict':22} expected")
        for r in rows:
            mark = "OK " if r["verdict_agree"] == "True" else "MISS"
            print(f"{mark} {r['sample_id']:8} {r['brands_extracted'] or '-':28} "
                  f"{r['verdict']:22} {r['verdict_expected']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
