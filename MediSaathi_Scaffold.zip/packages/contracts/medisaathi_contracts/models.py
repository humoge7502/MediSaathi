"""MediSaathi typed contracts (Pydantic v2).

The single source of truth for every boundary crossing. The TypeScript client
in apps/web is generated from the OpenAPI schema this package drives, so the
frontend cannot drift from the backend contract.
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field

# ---------------------------------------------------------------- enums


class Severity(str, Enum):
    none = "none"
    mild = "mild"
    moderate = "moderate"
    severe = "severe"


class VerdictKind(str, Enum):
    pass_ = "pass"
    interaction = "interaction"
    contraindication = "contraindication"
    duplicate_atc = "duplicate_atc"
    confirm_queue = "confirm_queue"
    refused = "refused"


class FieldSource(str, Enum):
    vision = "vision"
    user_confirmation = "user_confirmation"
    seed_fixture = "seed_fixture"


# ---------------------------------------------------------------- perception plane


class ExtractionField(BaseModel):
    """One OCR/vision-extracted prescription line field with its confidence."""

    raw_text: str
    brand_text: str = ""
    strength: str = ""
    dose: str = ""
    frequency: str = ""
    duration: str = ""
    confidence: float = Field(ge=0.0, le=1.0)
    source: FieldSource = FieldSource.vision


class ExtractionResult(BaseModel):
    sample_id: str
    fields: list[ExtractionField]
    engine: str = "fixture-v0"          # or "gemini-flash-vX" when live
    latency_ms: int = 0


# ---------------------------------------------------------------- safety plane


class NormalizedMedication(BaseModel):
    brand: str
    molecule: str
    form: str = ""
    atc: str = ""
    aware_class: str = ""
    jas_price_inr: Optional[float] = None
    fields: list[ExtractionField] = []


class InteractionFinding(BaseModel):
    molecule_a: str
    molecule_b: str
    severity: Severity
    mechanism: str
    source: str


class ContraindicationFinding(BaseModel):
    molecule: str
    condition_code: str
    severity: Severity
    note: str


class DuplicateFinding(BaseModel):
    atc: str
    brands: list[str]
    note: str


class SafetyReport(BaseModel):
    medications: list[NormalizedMedication]
    interactions: list[InteractionFinding]
    contraindications: list[ContraindicationFinding]
    duplicates: list[DuplicateFinding]
    checks: dict[str, bool]  # rule_name -> executed_ok


# ---------------------------------------------------------------- gate + verdict


class ConfirmItem(BaseModel):
    field_index: int
    raw_text: str
    confidence: float
    reason: str


class ProvenanceEntry(BaseModel):
    kind: str                      # extraction | safety_check | data_snapshot
    name: str
    source: str
    snapshot: str = "2026-09"


class Verdict(BaseModel):
    kind: VerdictKind
    headline: str
    detail: str = ""
    max_interaction_severity: Severity = Severity.none
    refusal_reason: Optional[str] = None
    provenance: list[ProvenanceEntry] = []


# ---------------------------------------------------------------- envelopes


class PlanSlot(BaseModel):
    slot: str
    value: str
    verified: bool


class SpokenPlan(BaseModel):
    language: str = "en"
    slots: list[PlanSlot]
    script: str
    audio_url: Optional[str] = None
    disclaimer: str = (
        "MediSaathi is an information tool, not a doctor. "
        "Discuss every medicine with your pharmacist or doctor."
    )


class PriceRow(BaseModel):
    brand: str
    molecule: str
    unit_price_inr: Optional[float] = None
    generic_available: bool = False
    generic_price_inr: Optional[float] = None
    source: str = "Jan Aushadhi"


class PrescriptionState(BaseModel):
    prescription_id: str
    sample_id: str
    extraction: Optional[ExtractionResult] = None
    safety: Optional[SafetyReport] = None
    verdict: Optional[Verdict] = None
    confirm_queue: list[ConfirmItem] = []
    spoken_plan: Optional[SpokenPlan] = None
    price_rows: list[PriceRow] = []
    meta: dict = {}


class Envelope(BaseModel):
    """Every API response is wrapped in this envelope."""

    ok: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None
    meta: dict = {"api_version": "v1", "engines_version": "fixture-v0"}
